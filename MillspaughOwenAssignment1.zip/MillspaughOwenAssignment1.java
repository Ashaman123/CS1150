/*
 *  Name: Owen Millspaugh
 *  Class: CS1150 
 *  Due:  Aug 30, 2023
 *  Description: Assignment #1 
 *  This program demonstrates that I understand basic program structure by 
 *  printing a couple paragraphs on the console that tell the instructor what I’m  
 *  passionate about.  It also gives a little practice with arithmetic in Java.
 */
public class MillspaughOwenAssignment1 {

public static void main(String[] args) {

// Part 1 – displaying information about myself
		System.out.println ("     My name is Owen Millspaugh. I am a computer science major. I am");
		System.out.println (" planning to work in the space and intel analyst fields using my");
		System.out.println (" degree. I have also considered going into the law field as a lawyer.");
		System.out.println (" I would specifically want to be working as a criminal prosecutor.");
		System.out.println ();
		System.out.println ("     I have played soccer my whole life, so I am a massive soccer");
		System.out.println (" fan. My favorite team is Manchester United. I have multiple teams");
		System.out.println (" in multiple countries that I like. I am also a Bohemians 1905 fan");
		System.out.println (" which is a team ive watched in Prague. I also love to travel and I've");
		System.out.println (" traveled to multiple other countries. I would love to go to England");
		System.out.println (" as well as Belgium and the Netherlands for my next international trip.");
//part 2
 // main
	System.out.println (" Kilometers     Miles      Feet       Inches");
	System.out.println ("---------------------------------------------");
	System.out.println ("5               " + (5*0.62) + "        " + (5*3280.84) +  "   " + (5*39370.1));  
	System.out.println ("25              " + (25*0.62) + "       " + (25*3280.84) +  "   " + (25*39370.1));  
	System.out.println ("50              " + (50*0.62) + "       " + (50*3280.84) +  "  " + (50*39370.1));  
	System.out.println ("100             " + (100*0.62) + "       " + (100*3280.84) +  "  " + (100*39370.1));  


}
   } // Assignment 1
